const REACT_APP_HOST_URL = process.env.REACT_APP_HOST_URL;


export default REACT_APP_HOST_URL;