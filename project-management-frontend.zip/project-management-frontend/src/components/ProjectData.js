//for testing purposes
export default {
    "lorem_ipsum": {
        id: "lorem ipsum",
        name: "Lorem Ipsum",
        manager: 'Project Manager: Mitsuha Miyamizu',
        date: 'Date Started: July 4, 2020',
        priority: 'Project Priority: High',
        status: 'Project Status: Ongoing',
        description: "Test for view project"
    },

    "ABC Coding Competition": {
        id: "abc coding",
        name: "ABC Coding Competition",
        manager: 'Project Manager: Von Atianzar',
        date: 'Date Started: February 25, 2020',
        priority: 'Project Priority: None',
        status: 'Project Status: Completed',
    },

    "Gamer's League Competition": {
        id: "gamer's league",
        name: "Gamer's League Competition",
        manager: 'Project Manager: Zeke Arellano',
        date: 'Date Started: March 2, 2020',
        priority: 'Project Priority: None',
        status: 'Project Status: Completed',
    },

    "Tech-Deck Exhibit": {
        id: "tech-deck",
        name: "Tech-Deck Exhibit",
        manager: 'Project Manager: Marco Dabon',
        date: 'Date Started: July 2, 2020',
        priority: 'Project Priority: Low',
        status: 'Project Status: Ongoing',
    },

    "Code Wars": {
        id: "code wars",
        name: "Code Wars",
        manager: 'Project Manager: Harriette Haw',
        date: 'Date Started: July 24, 2020',
        priority: 'Project Priority: Medium',
        status: 'Project Status: Ongoing',
    },
};